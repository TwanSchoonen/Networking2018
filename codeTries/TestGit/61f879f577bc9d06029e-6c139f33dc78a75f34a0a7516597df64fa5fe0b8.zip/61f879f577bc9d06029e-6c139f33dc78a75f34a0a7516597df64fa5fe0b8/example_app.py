from flask import Flask


app = Flask(__name__)

app.debug = True


@app.route('/')
def home():
    return 'App home'


from foo import mod
app.register_blueprint(mod, url_prefix='/foo')


if __name__ == '__main__':
    app.run()
