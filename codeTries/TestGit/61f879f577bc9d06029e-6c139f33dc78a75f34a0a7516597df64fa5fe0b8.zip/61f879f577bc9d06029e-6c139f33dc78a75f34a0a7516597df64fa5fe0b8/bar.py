"""
Note: can't put in a subdirectory for this example (GitHub Gists
doesn't allow subdirectories). Recommended to move this file to
foo/bar.py.
"""


routes = []


def ping_bar():
    return 'Ping bar'


routes.append(dict(
    rule='/ping-bar/',
    view_func=ping_bar))


def save_bar():
    return 'Save bar'


routes.append(dict(
    rule='/save-bar/',
    view_func=save_bar,
    options=dict(methods=['POST',])))
