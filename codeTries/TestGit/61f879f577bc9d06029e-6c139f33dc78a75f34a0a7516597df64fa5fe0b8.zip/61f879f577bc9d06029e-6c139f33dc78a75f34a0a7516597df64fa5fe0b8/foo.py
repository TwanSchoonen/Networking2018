"""
Note: can't put in a subdirectory for this example (GitHub Gists
doesn't allow subdirectories). Recommended to move this file to
foo/__init__.py, and to change the imports to
'from .bar' and 'from .baz'.
"""


from flask import Blueprint


mod = Blueprint('foo', __name__)


@mod.route('/')
def home():
    return 'Foo home'


from bar import routes as bar_routes
from baz import routes as baz_routes


routes = (
    bar_routes +
    baz_routes)

for r in routes:
    mod.add_url_rule(
        r['rule'],
        endpoint=r.get('endpoint', None),
        view_func=r['view_func'],
        **r.get('options', {}))
